#!/bin/bash
set -euxo pipefail
exec > >(tee /var/log/user-data.log | logger -t user-data -s 2>/dev/console) 2>&1

export DEBIAN_FRONTEND=noninteractive

AWS_REGION="eu-west-2"
S3_BUCKET="REPLACE_WITH_S3_BUCKET_NAME"
S3_KEY="student-registration-portal.zip"
DB_SECRET_ID="REPLACE_WITH_DB_SECRET_NAME_OR_ARN"
APP_DIR="/opt/student-registration-portal"
APP_PORT="3000"
APP_USER="appsvc"

apt-get update
apt-get install -y ca-certificates curl gnupg unzip jq awscli postgresql-client rsync build-essential python3 openssl

if ! command -v node >/dev/null 2>&1; then
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
  apt-get update
  apt-get install -y nodejs
fi

if ! id "$APP_USER" >/dev/null 2>&1; then
  useradd --system --create-home --shell /usr/sbin/nologin "$APP_USER"
fi

mkdir -p "$APP_DIR/source" "$APP_DIR/current"
rm -rf "$APP_DIR/source"/*

aws s3 cp "s3://$S3_BUCKET/$S3_KEY" /tmp/student-registration-portal.zip --region "$AWS_REGION"
unzip -oq /tmp/student-registration-portal.zip -d "$APP_DIR/source"

cd "$APP_DIR/source"

npm install

SECRET_JSON=$(aws secretsmanager get-secret-value \
  --region "$AWS_REGION" \
  --secret-id "$DB_SECRET_ID" \
  --query SecretString \
  --output text)

DB_HOST=$(echo "$SECRET_JSON" | jq -r '.host // .hostname')
DB_PORT=$(echo "$SECRET_JSON" | jq -r '.port // 5432')
DB_USER=$(echo "$SECRET_JSON" | jq -r '.username // .user')
DB_PASSWORD=$(echo "$SECRET_JSON" | jq -r '.password')
DB_NAME=$(echo "$SECRET_JSON" | jq -r '.dbname // .database // "student_portal"')

ENCODED_USER=$(python3 -c "import os, urllib.parse; print(urllib.parse.quote(os.environ['DB_USER']))" )
ENCODED_PASSWORD=$(python3 -c "import os, urllib.parse; print(urllib.parse.quote(os.environ['DB_PASSWORD']))" )

AUTH_SECRET_FILE="$APP_DIR/auth_secret"
if [ ! -f "$AUTH_SECRET_FILE" ]; then
  openssl rand -hex 32 > "$AUTH_SECRET_FILE"
fi
AUTH_SECRET=$(cat "$AUTH_SECRET_FILE")

DATABASE_URL="postgresql://${ENCODED_USER}:${ENCODED_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}?schema=public&sslmode=require"

cat > .env.production <<ENVFILE
DATABASE_URL='$DATABASE_URL'
AUTH_SECRET='$AUTH_SECRET'
PORT='$APP_PORT'
NODE_ENV='production'
ENVFILE

set -a
source ./.env.production
set +a

PGPASSWORD="$DB_PASSWORD" psql "host=$DB_HOST port=$DB_PORT dbname=$DB_NAME user=$DB_USER sslmode=require" -c 'SELECT 1;'

npx prisma migrate deploy
npx prisma generate
npm run db:seed
npm run build

rsync -a --delete .next/standalone/ "$APP_DIR/current/"
mkdir -p "$APP_DIR/current/.next"
rsync -a .next/static/ "$APP_DIR/current/.next/static/"
if [ -d public ]; then
  rsync -a public/ "$APP_DIR/current/public/"
fi
cp .env.production "$APP_DIR/current/.env.production"

cat > /etc/systemd/system/student-portal.service <<SERVICE
[Unit]
Description=Student Registration Portal
After=network.target

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR/current
EnvironmentFile=$APP_DIR/current/.env.production
Environment=HOSTNAME=0.0.0.0
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

chown -R "$APP_USER":"$APP_USER" "$APP_DIR"
systemctl daemon-reload
systemctl enable student-portal
systemctl restart student-portal
systemctl status student-portal --no-pager
