# Student Registration Portal

A full stack student registration portal built with **Next.js**, **Prisma**, and **PostgreSQL**.

Students can:

- Create an account
- Log in securely
- Update their profile
- Register courses
- Drop courses
- View announcements

The application is designed to be self-hosted on **Ubuntu EC2** and connected to **Amazon RDS PostgreSQL**. It supports deployment using **S3 artifacts**, **Secrets Manager**, **user data**, and **systemd**.

## Stack

- Next.js App Router
- Prisma ORM
- PostgreSQL
- bcrypt password hashing
- JWT cookie session using `jose`
- AWS EC2 + RDS + S3 + Secrets Manager + CloudWatch

## Local setup

1. Copy the environment file:

```bash
cp .env.example .env
```

2. Set your database connection string and auth secret in `.env`.

3. Install dependencies:

```bash
npm install
```

4. Apply database migrations and seed starter data:

```bash
npx prisma migrate deploy
npm run db:seed
```

5. Start the app:

```bash
npm run dev
```

## Main routes

- `/` - landing page
- `/register` - student registration
- `/login` - login page
- `/dashboard` - overview and profile update
- `/dashboard/courses` - course registration and drop
- `/dashboard/settings` - password change
- `/api/health` - health check for ALB

## Database models

- `Student`
- `Course`
- `Enrollment`
- `Announcement`

## Production deployment

A full AWS deployment guide is included in:

```text
DEPLOY_AWS.md
```

User data template:

```text
infra/user-data.sh
```

IAM inline policy template:

```text
infra/ec2-inline-policy.json
```

RDS CPU alarm helper:

```text
infra/create-rds-cpu-alarm.sh
```
