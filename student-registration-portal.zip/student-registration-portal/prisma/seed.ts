import { PrismaClient, Semester } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const courses = [
    { code: 'CSC101', title: 'Introduction to Computer Science', unit: 3, semester: Semester.FIRST },
    { code: 'MTH101', title: 'General Mathematics I', unit: 3, semester: Semester.FIRST },
    { code: 'GST101', title: 'Use of English and Communication', unit: 2, semester: Semester.FIRST },
    { code: 'CSC201', title: 'Data Structures and Algorithms', unit: 3, semester: Semester.SECOND },
    { code: 'CSC203', title: 'Database Systems', unit: 3, semester: Semester.SECOND },
    { code: 'CSC205', title: 'Computer Networks', unit: 3, semester: Semester.SECOND }
  ];

  for (const course of courses) {
    await prisma.course.upsert({
      where: { code: course.code },
      update: course,
      create: course
    });
  }

  const announcements = [
    {
      title: 'Welcome to the Student Portal',
      body: 'Complete your profile, review available courses, and register before the semester deadline.'
    },
    {
      title: 'Course Registration Window Open',
      body: 'Students can now register courses for the current session directly from the portal dashboard.'
    }
  ];

  for (const announcement of announcements) {
    await prisma.announcement.upsert({
      where: { title: announcement.title },
      update: announcement,
      create: announcement
    });
  }
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
