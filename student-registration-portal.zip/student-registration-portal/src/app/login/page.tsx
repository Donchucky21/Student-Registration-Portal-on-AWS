import Link from 'next/link';
import { loginStudent } from '@/lib/actions';

export default async function LoginPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;

  return (
    <main className="container" style={{ padding: '2rem 0 3rem' }}>
      <div className="auth-grid">
        <div className="form-card" style={{ maxWidth: 560, margin: '0 auto' }}>
          <div className="kicker">Welcome back</div>
          <h2>Sign in to your portal</h2>
          <p>Access your dashboard, course registrations, and student announcements.</p>

          {params.error ? <div className="notice error">{params.error}</div> : null}

          <form action={loginStudent}>
            <label>
              Email address
              <input name="email" type="email" placeholder="student@example.com" required />
            </label>
            <label>
              Password
              <input name="password" type="password" placeholder="Enter your password" required />
            </label>
            <button className="primary" type="submit">
              Sign in
            </button>
          </form>

          <p>
            New student? <Link href="/register">Create an account</Link>
          </p>
        </div>
      </div>
    </main>
  );
}
