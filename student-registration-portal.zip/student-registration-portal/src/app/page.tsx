import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export default async function HomePage() {
  const [courseCount, announcementCount] = await Promise.all([
    prisma.course.count(),
    prisma.announcement.count({ where: { published: true } })
  ]);

  return (
    <main>
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <div className="kicker">Modern academic operations</div>
            <h1>Student registration portal built for real-world deployment.</h1>
            <p>
              A production-style full stack portal where students can sign up, log in, manage their profile,
              register courses, and stay updated with announcements, all backed by PostgreSQL.
            </p>
            <div className="button-row">
              <Link className="button primary" href="/register">
                Create student account
              </Link>
              <Link className="button secondary" href="/login">
                Sign in to portal
              </Link>
            </div>
          </div>

          <div className="hero-panel">
            <div className="metrics-grid">
              <div className="metric">
                <div>
                  <div className="label">Courses</div>
                  <p>Ready to register</p>
                </div>
                <strong>{courseCount}</strong>
              </div>
              <div className="metric">
                <div>
                  <div className="label">Updates</div>
                  <p>Portal announcements</p>
                </div>
                <strong>{announcementCount}</strong>
              </div>
              <div className="metric">
                <div>
                  <div className="label">Platform</div>
                  <p>Next.js + Prisma</p>
                </div>
                <strong>Live</strong>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container" style={{ paddingBottom: '2rem' }}>
        <div className="feature-grid">
          <div className="card">
            <h3>Secure onboarding</h3>
            <p>Create an account using student number, department, level, and password credentials.</p>
          </div>
          <div className="card">
            <h3>Course registration</h3>
            <p>Students can register and drop courses from a dashboard that reads directly from PostgreSQL.</p>
          </div>
          <div className="card">
            <h3>Self-hosted deployment</h3>
            <p>Deploy on Ubuntu EC2, run Prisma migrations, and fetch database credentials from Secrets Manager.</p>
          </div>
        </div>
      </section>

      <footer className="container footer">Built for an AWS deployment workflow with EC2, RDS PostgreSQL, S3, and Secrets Manager.</footer>
    </main>
  );
}
