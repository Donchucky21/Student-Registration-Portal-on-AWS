import { prisma } from '@/lib/prisma';
import { requireStudent } from '@/lib/auth';
import { updateProfile } from '@/lib/actions';
import { Sidebar } from '@/components/Sidebar';

export default async function DashboardPage() {
  const student = await requireStudent();
  const announcements = await prisma.announcement.findMany({
    where: { published: true },
    orderBy: { createdAt: 'desc' },
    take: 5
  });

  return (
    <div className="dashboard-grid">
      <Sidebar studentName={student.fullName} studentNumber={student.studentNumber} currentPath="/dashboard" />
      <div className="content">
        <div className="kicker">Portal overview</div>
        <h2>Hello, {student.fullName.split(' ')[0]}</h2>
        <p>Use your portal to keep your profile accurate and manage your registered courses.</p>

        <div className="metrics-grid" style={{ marginTop: '1rem' }}>
          <div className="stat card">
            <div className="label">Registered courses</div>
            <h3>{student.enrollments.length}</h3>
            <p>Courses currently active in your portal.</p>
          </div>
          <div className="stat card">
            <div className="label">Department</div>
            <h3>{student.department}</h3>
            <p>Academic unit tied to your registration record.</p>
          </div>
          <div className="stat card">
            <div className="label">Level</div>
            <h3>{student.level}</h3>
            <p>Current academic level on file.</p>
          </div>
        </div>

        <div className="course-grid" style={{ marginTop: '1rem' }}>
          <div className="card">
            <h3>Profile details</h3>
            <form action={updateProfile}>
              <label>
                Full name
                <input name="fullName" defaultValue={student.fullName} required />
              </label>
              <div className="grid-2">
                <label>
                  Phone number
                  <input name="phone" defaultValue={student.phone ?? ''} />
                </label>
                <label>
                  Department
                  <input name="department" defaultValue={student.department} required />
                </label>
              </div>
              <div className="grid-2">
                <label>
                  Level
                  <input name="level" defaultValue={student.level} required />
                </label>
                <label>
                  Date of birth
                  <input
                    name="dateOfBirth"
                    type="date"
                    defaultValue={student.dateOfBirth ? student.dateOfBirth.toISOString().slice(0, 10) : ''}
                  />
                </label>
              </div>
              <button className="primary" type="submit">
                Save profile updates
              </button>
            </form>
          </div>

          <div className="card">
            <h3>Recent announcements</h3>
            <div className="list">
              {announcements.map((announcement) => (
                <div className="list-item" key={announcement.id}>
                  <div className="label">Notice</div>
                  <h3 style={{ marginTop: '0.6rem' }}>{announcement.title}</h3>
                  <p>{announcement.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
