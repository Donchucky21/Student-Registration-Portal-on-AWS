import { Sidebar } from '@/components/Sidebar';
import { changePassword } from '@/lib/actions';
import { requireStudent } from '@/lib/auth';

export default async function SettingsPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const student = await requireStudent();
  const params = await searchParams;

  return (
    <div className="dashboard-grid">
      <Sidebar studentName={student.fullName} studentNumber={student.studentNumber} currentPath="/dashboard/settings" />
      <div className="content">
        <div className="kicker">Account security</div>
        <h2>Security settings</h2>
        <p>Update your portal password and keep your account protected.</p>

        {params.error ? <div className="notice error">{params.error}</div> : null}
        {params.success ? <div className="notice success">{params.success}</div> : null}

        <div className="card" style={{ maxWidth: 700, marginTop: '1rem' }}>
          <h3>Change password</h3>
          <form action={changePassword}>
            <label>
              Current password
              <input name="currentPassword" type="password" required />
            </label>
            <label>
              New password
              <input name="newPassword" type="password" minLength={8} required />
            </label>
            <button className="primary" type="submit">
              Update password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
