import { Sidebar } from '@/components/Sidebar';
import { dropCourse, registerCourse } from '@/lib/actions';
import { requireStudent } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export default async function CoursesPage() {
  const student = await requireStudent();

  const [courses, enrollments] = await Promise.all([
    prisma.course.findMany({ orderBy: [{ semester: 'asc' }, { code: 'asc' }] }),
    prisma.enrollment.findMany({
      where: { studentId: student.id, status: 'REGISTERED' },
      include: { course: true },
      orderBy: { createdAt: 'desc' }
    })
  ]);

  const registeredCourseIds = new Set(enrollments.map((item) => item.courseId));
  const availableCourses = courses.filter((course) => !registeredCourseIds.has(course.id));

  return (
    <div className="dashboard-grid">
      <Sidebar studentName={student.fullName} studentNumber={student.studentNumber} currentPath="/dashboard/courses" />
      <div className="content">
        <div className="kicker">Course operations</div>
        <h2>Register or drop courses</h2>
        <p>Manage all course actions from one place. Changes are stored directly in PostgreSQL.</p>

        <div className="course-grid" style={{ marginTop: '1rem' }}>
          <div className="table-wrap">
            <h3>Available courses</h3>
            <table className="table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Title</th>
                  <th>Unit</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {availableCourses.length === 0 ? (
                  <tr>
                    <td colSpan={4}>No more courses available for registration.</td>
                  </tr>
                ) : (
                  availableCourses.map((course) => (
                    <tr key={course.id}>
                      <td>{course.code}</td>
                      <td>
                        {course.title}
                        <div className="label" style={{ marginTop: '0.5rem' }}>
                          {course.semester} semester
                        </div>
                      </td>
                      <td>{course.unit}</td>
                      <td>
                        <form action={registerCourse}>
                          <input type="hidden" name="courseId" value={course.id} />
                          <button className="primary" type="submit">
                            Register
                          </button>
                        </form>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="table-wrap">
            <h3>My registered courses</h3>
            <table className="table">
              <thead>
                <tr>
                  <th>Code</th>
                  <th>Title</th>
                  <th>Unit</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {enrollments.length === 0 ? (
                  <tr>
                    <td colSpan={4}>You have not registered any courses yet.</td>
                  </tr>
                ) : (
                  enrollments.map((enrollment) => (
                    <tr key={enrollment.id}>
                      <td>{enrollment.course.code}</td>
                      <td>{enrollment.course.title}</td>
                      <td>{enrollment.course.unit}</td>
                      <td>
                        <form action={dropCourse}>
                          <input type="hidden" name="enrollmentId" value={enrollment.id} />
                          <button className="danger" type="submit">
                            Drop
                          </button>
                        </form>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
