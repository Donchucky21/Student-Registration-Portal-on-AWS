import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Student Registration Portal',
  description: 'Full stack student registration portal built with Next.js, Prisma, and PostgreSQL.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
