import Link from 'next/link';
import { registerStudent } from '@/lib/actions';

export default async function RegisterPage({
  searchParams
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;

  return (
    <main className="container" style={{ padding: '2rem 0 3rem' }}>
      <div className="auth-grid">
        <div className="form-card" style={{ maxWidth: 780, margin: '0 auto' }}>
          <div className="kicker">Student sign up</div>
          <h2>Create your portal account</h2>
          <p>Provide your registration details once and start managing your academic profile online.</p>

          {params.error ? <div className="notice error">{params.error}</div> : null}

          <form action={registerStudent}>
            <div className="grid-2">
              <label>
                Full name
                <input name="fullName" placeholder="Jane Doe" required />
              </label>
              <label>
                Student number
                <input name="studentNumber" placeholder="STU-1001" required />
              </label>
            </div>

            <div className="grid-2">
              <label>
                Email address
                <input name="email" type="email" placeholder="student@example.com" required />
              </label>
              <label>
                Phone number
                <input name="phone" placeholder="+44..." />
              </label>
            </div>

            <div className="grid-2">
              <label>
                Department
                <input name="department" placeholder="Computer Science" required />
              </label>
              <label>
                Level
                <select name="level" defaultValue="100" required>
                  <option value="100">100</option>
                  <option value="200">200</option>
                  <option value="300">300</option>
                  <option value="400">400</option>
                  <option value="Postgraduate">Postgraduate</option>
                </select>
              </label>
            </div>

            <div className="grid-2">
              <label>
                Date of birth
                <input name="dateOfBirth" type="date" />
              </label>
              <label>
                Password
                <input name="password" type="password" placeholder="Minimum 8 characters" required />
              </label>
            </div>

            <button className="primary" type="submit">
              Create account and continue
            </button>
          </form>

          <p>
            Already have an account? <Link href="/login">Sign in here</Link>
          </p>
        </div>
      </div>
    </main>
  );
}
