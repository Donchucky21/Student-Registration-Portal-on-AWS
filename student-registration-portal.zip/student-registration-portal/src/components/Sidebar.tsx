import Link from 'next/link';
import { logoutStudent } from '@/lib/actions';

type Props = {
  studentName: string;
  studentNumber: string;
  currentPath: string;
};

const links = [
  { href: '/dashboard', label: 'Overview' },
  { href: '/dashboard/courses', label: 'Course Registration' },
  { href: '/dashboard/settings', label: 'Security Settings' }
];

export function Sidebar({ studentName, studentNumber, currentPath }: Props) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <span className="brand-badge">SP</span>
        <div>
          <div>Student Portal</div>
          <small style={{ color: '#94a3b8' }}>Next.js + PostgreSQL</small>
        </div>
      </div>

      <div className="card" style={{ marginTop: '1.25rem' }}>
        <div className="label">Student</div>
        <h3 style={{ marginTop: '0.6rem' }}>{studentName}</h3>
        <p>{studentNumber}</p>
      </div>

      <nav className="nav-links">
        {links.map((link) => (
          <Link key={link.href} href={link.href} className={currentPath === link.href ? 'active' : ''}>
            {link.label}
          </Link>
        ))}
      </nav>

      <form action={logoutStudent} style={{ marginTop: 'auto', display: 'block' }}>
        <button className="secondary" style={{ width: '100%', marginTop: '2rem' }} type="submit">
          Sign out
        </button>
      </form>
    </aside>
  );
}
