import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { SignJWT, jwtVerify } from 'jose';
import { prisma } from '@/lib/prisma';

const COOKIE_NAME = 'portal_session';
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || 'development-secret-change-me');

export type SessionPayload = {
  sub: string;
  email: string;
  studentNumber: string;
};

export async function createSession(payload: SessionPayload) {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);
}

export async function setSessionCookie(token: string) {
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 60 * 60 * 24 * 7
  });
}

export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

export async function getSessionPayload() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;

  if (!token) return null;

  try {
    const verified = await jwtVerify(token, secret);
    return verified.payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

export async function requireStudent() {
  const session = await getSessionPayload();

  if (!session?.sub) {
    redirect('/login');
  }

  const student = await prisma.student.findUnique({
    where: { id: session.sub },
    include: {
      enrollments: {
        where: { status: 'REGISTERED' },
        include: { course: true },
        orderBy: { createdAt: 'desc' }
      }
    }
  });

  if (!student) {
    redirect('/login');
  }

  return student;
}
