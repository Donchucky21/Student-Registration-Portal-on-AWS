'use server';

import bcrypt from 'bcryptjs';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { createSession, clearSessionCookie, requireStudent, setSessionCookie } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

const registerSchema = z.object({
  fullName: z.string().min(3),
  studentNumber: z.string().min(4),
  email: z.string().email(),
  phone: z.string().optional(),
  department: z.string().min(2),
  level: z.string().min(1),
  dateOfBirth: z.string().optional(),
  password: z.string().min(8)
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

export async function registerStudent(formData: FormData) {
  const parsed = registerSchema.safeParse({
    fullName: formData.get('fullName'),
    studentNumber: formData.get('studentNumber'),
    email: formData.get('email'),
    phone: formData.get('phone') || undefined,
    department: formData.get('department'),
    level: formData.get('level'),
    dateOfBirth: formData.get('dateOfBirth') || undefined,
    password: formData.get('password')
  });

  if (!parsed.success) {
    redirect('/register?error=Please%20complete%20all%20required%20fields%20correctly.');
  }

  const existing = await prisma.student.findFirst({
    where: {
      OR: [
        { email: parsed.data.email.toLowerCase() },
        { studentNumber: parsed.data.studentNumber.trim().toUpperCase() }
      ]
    }
  });

  if (existing) {
    redirect('/register?error=Student%20already%20exists%20with%20that%20email%20or%20student%20number.');
  }

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);

  const student = await prisma.student.create({
    data: {
      fullName: parsed.data.fullName.trim(),
      studentNumber: parsed.data.studentNumber.trim().toUpperCase(),
      email: parsed.data.email.trim().toLowerCase(),
      phone: parsed.data.phone?.toString().trim() || null,
      department: parsed.data.department.trim(),
      level: parsed.data.level.trim(),
      dateOfBirth: parsed.data.dateOfBirth ? new Date(parsed.data.dateOfBirth) : null,
      passwordHash
    }
  });

  const token = await createSession({
    sub: student.id,
    email: student.email,
    studentNumber: student.studentNumber
  });

  await setSessionCookie(token);
  redirect('/dashboard');
}

export async function loginStudent(formData: FormData) {
  const parsed = loginSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password')
  });

  if (!parsed.success) {
    redirect('/login?error=Enter%20a%20valid%20email%20and%20password.');
  }

  const student = await prisma.student.findUnique({
    where: { email: parsed.data.email.toLowerCase() }
  });

  if (!student) {
    redirect('/login?error=Invalid%20login%20details.');
  }

  const isValid = await bcrypt.compare(parsed.data.password, student.passwordHash);
  if (!isValid) {
    redirect('/login?error=Invalid%20login%20details.');
  }

  const token = await createSession({
    sub: student.id,
    email: student.email,
    studentNumber: student.studentNumber
  });

  await setSessionCookie(token);
  redirect('/dashboard');
}

export async function logoutStudent() {
  await clearSessionCookie();
  redirect('/login');
}

export async function updateProfile(formData: FormData) {
  const student = await requireStudent();

  await prisma.student.update({
    where: { id: student.id },
    data: {
      fullName: String(formData.get('fullName') || student.fullName).trim(),
      phone: String(formData.get('phone') || '').trim() || null,
      department: String(formData.get('department') || student.department).trim(),
      level: String(formData.get('level') || student.level).trim(),
      dateOfBirth: String(formData.get('dateOfBirth') || '').trim()
        ? new Date(String(formData.get('dateOfBirth')))
        : null
    }
  });

  revalidatePath('/dashboard');
  redirect('/dashboard');
}

export async function registerCourse(formData: FormData) {
  const student = await requireStudent();
  const courseId = String(formData.get('courseId') || '');

  if (!courseId) {
    redirect('/dashboard/courses');
  }

  await prisma.enrollment.upsert({
    where: {
      studentId_courseId: {
        studentId: student.id,
        courseId
      }
    },
    update: {
      status: 'REGISTERED'
    },
    create: {
      studentId: student.id,
      courseId,
      status: 'REGISTERED'
    }
  });

  revalidatePath('/dashboard/courses');
  revalidatePath('/dashboard');
  redirect('/dashboard/courses');
}

export async function dropCourse(formData: FormData) {
  const student = await requireStudent();
  const enrollmentId = String(formData.get('enrollmentId') || '');

  if (!enrollmentId) {
    redirect('/dashboard/courses');
  }

  await prisma.enrollment.updateMany({
    where: {
      id: enrollmentId,
      studentId: student.id
    },
    data: {
      status: 'DROPPED'
    }
  });

  revalidatePath('/dashboard/courses');
  revalidatePath('/dashboard');
  redirect('/dashboard/courses');
}

export async function changePassword(formData: FormData) {
  const student = await requireStudent();

  const currentPassword = String(formData.get('currentPassword') || '');
  const newPassword = String(formData.get('newPassword') || '');

  if (newPassword.length < 8) {
    redirect('/dashboard/settings?error=New%20password%20must%20be%20at%20least%208%20characters.');
  }

  const valid = await bcrypt.compare(currentPassword, student.passwordHash);
  if (!valid) {
    redirect('/dashboard/settings?error=Current%20password%20is%20incorrect.');
  }

  const passwordHash = await bcrypt.hash(newPassword, 12);
  await prisma.student.update({
    where: { id: student.id },
    data: { passwordHash }
  });

  redirect('/dashboard/settings?success=Password%20updated%20successfully.');
}
