# AWS deployment guide for the Student Registration Portal

This guide deploys the included Next.js application on a private Ubuntu EC2 instance, connects it to a private Amazon RDS PostgreSQL database, stores database credentials in AWS Secrets Manager, pulls the application bundle from Amazon S3, and keeps the app running with systemd.

## Target architecture

- Public subnets:
  - Internet-facing Application Load Balancer
  - NAT Gateway
- Private app subnets:
  - Ubuntu EC2 instance running the Next.js app on port 3000
- Private DB subnets:
  - Amazon RDS for PostgreSQL with public access disabled
- Supporting services:
  - S3 for the application bundle
  - Secrets Manager for DB credentials
  - CloudWatch + SNS for notifications
  - Optional Session Manager instead of opening SSH publicly

## 1) Create the database in private subnets

1. Go to **RDS > Subnet groups**.
2. Create a DB subnet group using **two private subnets in different Availability Zones**.
3. Go to **RDS > Create database**.
4. Choose **PostgreSQL**.
5. Use **Standard create**.
6. Set the DB instance identifier, master username, and password.
7. In **Connectivity**:
   - Choose your VPC.
   - Choose the DB subnet group created above.
   - Set **Public access = No**.
   - Attach the **DB security group**.
8. Create the database.

### Security group design

Create these security groups:

- `alb-sg`
  - Inbound: 80 and 443 from `0.0.0.0/0`
  - Outbound: allow all
- `app-sg`
  - Inbound: 3000 from `alb-sg`
  - Optional inbound: 22 from `bastion-sg` only if you are using SSH
  - Outbound: allow all
- `db-sg`
  - Inbound: 5432 from `app-sg`
  - Optional inbound: 5432 from `bastion-sg` if you want to connect with `psql` from a bastion host
  - Outbound: allow all

The database should not allow inbound from the internet.

## 2) Store DB credentials in Secrets Manager

Create a secret in **Secrets Manager** using the **database credentials** template or JSON similar to the following:

```json
{
  "username": "postgres",
  "password": "REPLACE_ME",
  "engine": "postgres",
  "host": "your-rds-endpoint.rds.amazonaws.com",
  "port": 5432,
  "dbname": "student_portal"
}
```

Note the secret name or ARN. The user data script expects that secret.

## 3) Package the application and upload it to S3

From the root of this project:

```bash
zip -r student-registration-portal.zip . \
  -x "node_modules/*" \
  -x ".next/*" \
  -x ".git/*"
```

Create or use an S3 bucket and upload the zip:

```bash
aws s3 cp student-registration-portal.zip s3://YOUR_BUCKET_NAME/student-registration-portal.zip
```

## 4) Create the EC2 instance role

Create an IAM role for EC2 with:

- Trust policy for `ec2.amazonaws.com`
- Managed policy: `AmazonSSMManagedInstanceCore` if you want Session Manager access
- Inline policy from `infra/ec2-inline-policy.json` after replacing placeholders

If the S3 object or secret uses a customer-managed KMS key, keep the `kms:Decrypt` permission.

## 5) Launch the Ubuntu EC2 instance in a private subnet

1. Go to **EC2 > Launch template** or **Launch instance**.
2. Choose **Ubuntu**.
3. Place the instance in a **private subnet** with **Auto-assign public IP disabled**.
4. Attach **app-sg**.
5. Attach the **EC2 IAM role**.
6. Paste the contents of `infra/user-data.sh` into user data after replacing:
   - `AWS_REGION`
   - `S3_BUCKET`
   - `S3_KEY`
   - `DB_SECRET_ID`
7. Launch the instance.

### Important network requirement

Because the EC2 instance is private, it still needs outbound access to:

- `deb.nodesource.com` and Ubuntu package repositories
- Amazon S3
- Secrets Manager

The simplest path is a **NAT Gateway**. If you do not want NAT, create VPC endpoints for the services you use and make sure package installation is handled another way.

## 6) Create the Application Load Balancer

1. Create a **target group** for instances on port **3000**.
2. Use **HTTP** as the protocol for the target group.
3. Set the health check path to:

```text
/api/health
```

4. Create an **internet-facing ALB** in your **public subnets**.
5. Attach `alb-sg`.
6. Forward listener 80 (and 443 if you add ACM later) to the target group.
7. Register the private EC2 instance or attach the Auto Scaling group if you use one.

## 7) Verify user data completed successfully

If you use Session Manager or a bastion host, connect to the EC2 instance and check:

```bash
sudo systemctl status student-portal
sudo journalctl -u student-portal -n 100 --no-pager
sudo tail -n 100 /var/log/user-data.log
curl http://localhost:3000/api/health
```

You should also see the ALB target become healthy.

## 8) Test database connectivity from EC2

Use the secret values to test directly with `psql` from the application server or a bastion host:

```bash
PGPASSWORD='YOUR_PASSWORD' psql \
  "host=YOUR_RDS_ENDPOINT port=5432 dbname=student_portal user=postgres sslmode=require"
```

Then verify tables:

```sql
\dt
SELECT * FROM "Course";
SELECT * FROM "Announcement";
```

## 9) Create CloudWatch alarm and notifications

### SNS notification topic

1. Go to **SNS > Topics > Create topic**.
2. Create a **Standard** topic.
3. Create an **email subscription**.
4. Confirm the subscription from your email inbox.

### RDS CPU alarm

Use the helper script in `infra/create-rds-cpu-alarm.sh` after replacing the placeholders, or run directly:

```bash
aws cloudwatch put-metric-alarm \
  --region eu-west-2 \
  --alarm-name student-portal-db-cpu-over-80 \
  --alarm-description "RDS CPUUtilization over 80 percent for 5 minutes" \
  --namespace AWS/RDS \
  --metric-name CPUUtilization \
  --dimensions Name=DBInstanceIdentifier,Value=YOUR_DB_INSTANCE_IDENTIFIER \
  --statistic Average \
  --period 300 \
  --evaluation-periods 1 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --treat-missing-data notBreaching \
  --alarm-actions YOUR_SNS_TOPIC_ARN \
  --ok-actions YOUR_SNS_TOPIC_ARN
```

## 10) Application URLs to verify

- Landing page: `http://YOUR_ALB_DNS_NAME/`
- Registration page: `http://YOUR_ALB_DNS_NAME/register`
- Login page: `http://YOUR_ALB_DNS_NAME/login`
- Health check: `http://YOUR_ALB_DNS_NAME/api/health`

## 11) What the app already does

- Student account registration
- Secure login with hashed passwords
- Profile updates
- Course registration
- Course drop operation
- Announcement feed
- PostgreSQL persistence through Prisma
- Prisma migration deploy on instance boot
- Seeded starter courses and announcements

## 12) Recommended next improvements

- Add role-based admin panel for managing announcements and courses
- Add email verification or password reset
- Put the app behind HTTPS with ACM and an ALB 443 listener
- Use an Auto Scaling group and launch template for production
- Add CloudWatch Logs agent and dashboards
